import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import CartItem from "./cart/CartItem";

function CartPage() {
    const [cartData, setCartData] = useState([]);

    useEffect(() => {
      // Retrieve userId from userData in localStorage
      const userData = JSON.parse(localStorage.getItem('userData'));
      const userId = userData.userId; // Assuming the structure is userData.userId
  
      // Fetch cart data for the user
      fetch(`http://localhost:8080/cart/${userId}`)
        .then(response => response.json())
        .then(data => {
          setCartData(data);
        })
        .catch(error => {
          console.error('Error fetching cart data:', error);
        });
    }, []);
    return (
        <div>
            <h1 className="container">CART</h1>
            <hr />
            <div className="container-fluid">
                <div className="row">
                    

                    <div className="col-8 px-5">
                    {cartData.map(item => (
              <CartItem
                key={item.itemId}
                itemId={item.itemId}
                breedName={item.breedName}
                price={item.price}
                gender={item.gender}
                age={item.petAge}
                // Pass other relevant data using props
              />
                ))}


                    </div>



                    <div className="col-lg-4">
                        



                        <div className="container text-center py-3 bg-light">
                            {/* <!-- For 2 selected items --> */}
                            <h4>Items selected</h4>
                            <h6>Subtotal (2 items): </h6><h5>1,76,990</h5>
                            <Link to="/Buy" className="btn px-4 bg-warning">Proceed to buy</Link>
                        </div>



                    </div>
                </div>
            </div>
            <br />

            
        </div>
    );
}

export default CartPage;
